<?php
/*
 *
 */
namespace FishPig\WordPress\Model\Logger;

/* Parent Class */
use Magento\Framework\Logger\Handler\Base;

class Handler extends Base
{
	/**
	 * Logging level
	 * @var int
	 */
	protected $loggerType = \Monolog\Logger::INFO;
	
	/**
	 * File name
	 * @var string
	 */
	protected $fileName = '/var/log/wordpress.log';
}
