<?php
/**
 * Template Name: Full Width (1 Column)
 * Template Post Type: post, page
 */

get_template_part('index');
