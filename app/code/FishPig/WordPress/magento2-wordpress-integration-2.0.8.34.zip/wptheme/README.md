# WordPress Theme - FishPig 
This is the WordPress theme auto installed by [Fishpig_Wordpress (Magento 1)](https://github.com/bentideswell/magento1-wordpress-integration) and [FishPig_WordPress (Magento 2)](https://github.com/bentideswell/magento2-wordpress-integration) when WordPress is integrated into Magento.
