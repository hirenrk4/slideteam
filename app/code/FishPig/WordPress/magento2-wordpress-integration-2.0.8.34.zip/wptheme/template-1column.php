<?php
/**
 * Template Name: 1 Column
 * Template Post Type: post, page
 */

get_template_part('index');
