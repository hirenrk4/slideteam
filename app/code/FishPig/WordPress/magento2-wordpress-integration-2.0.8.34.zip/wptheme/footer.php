<?php
/**
 *
**/
?>
		<!--WP-FOOTER--><?php wp_footer() ?><!--/WP-FOOTER-->
	</body>
</html>